// Charger les champignons depuis le Local Storage s'ils existent, sinon utiliser une liste par défaut
let mushrooms = JSON.parse(localStorage.getItem('mushrooms')) || [
    {
        id: 1,
        name: "Champignon de Paris",
        photo: "paris.jpg",
        humidity: "80%",
        temperature: "16°C - 18°C",
        origin: "France"
    },
    {
        id: 2,
        name: "Shiitake",
        photo: "shiitake.jpg",
        humidity: "85%",
        temperature: "20°C - 24°C",
        origin: "Asie"
    },
    {
        id: 3,
        name: "Girolle",
        photo: "girolle.jpg", 
        humidity: "70%",
        temperature: "15°C - 18°C",
        origin: "Europe"
    },
    {
        id: 4,
        name: "Lion's Mane",
        photo: "lions_mane.jpg",
        humidity: "85%",
        temperature: "18°C - 24°C",
        origin: "Asie"
    },
    {
        id: 5,
        name: "Truffe",
        photo: "truffe.jpg",
        humidity: "90%",
        temperature: "12°C - 16°C",
        origin: "France, Italie"
    },
    {
        id: 6,
        name: "Pleurotte",
        photo: "pleurotte.jpg",
        humidity: "75%",
        temperature: "18°C - 22°C",
        origin: "Europe, Asie"
    }
];

// Fonction pour afficher la liste des champignons avec photos et noms
function displayMushrooms() {
    const mushroomList = document.getElementById("mushrooms");
    mushroomList.innerHTML = "";
    mushrooms.forEach(mushroom => {
        let mushroomDiv = document.createElement("div");
        mushroomDiv.className = "mushroom-item";
        mushroomDiv.innerHTML = `
            <h3>${mushroom.name}</h3>
            <img src="${mushroom.photo}" alt="${mushroom.name}">
        `;
        mushroomDiv.onclick = () => displayDetails(mushroom);
        mushroomList.appendChild(mushroomDiv);
    });
}

// Fonction pour afficher les détails du champignon
function displayDetails(mushroom) {
    const detailsSection = document.getElementById("mushroom-details");
    detailsSection.style.display = "block";

    const detailsDiv = document.getElementById("details");
    detailsDiv.innerHTML = `
        <h3>${mushroom.name}</h3>
        <img src="${mushroom.photo}" alt="${mushroom.name}">
        <p>Humidité : ${mushroom.humidity}</p>
        <p>Température idéale : ${mushroom.temperature}</p>
        <p>Pays d'origine : ${mushroom.origin}</p>
        <button onclick="editMushroom(${mushroom.id})">Modifier</button>
        <button onclick="deleteMushroom(${mushroom.id})">Supprimer</button>
    `;
}

// Fonction pour afficher le formulaire d'ajout
document.getElementById('show-form-btn').onclick = () => {
    document.getElementById('add-mushroom-form').style.display = 'block';
};

// Fonction pour gérer l'ajout d'un champignon via le formulaire
document.getElementById('mushroomForm').onsubmit = function(event) {

    event.preventDefault(); // Empêche le rechargement de la page

    // Récupérer les données du formulaire
    const newMushroom = {
        id: mushrooms.length + 1, // Générer un nouvel ID
        name: document.getElementById('name').value,
        photo: document.getElementById('photo').value,
        humidity: document.getElementById('humidity').value,
        temperature: document.getElementById('temperature').value,
        origin: document.getElementById('origin').value
    };

    // Ajouter le nouveau champignon à la liste
    mushrooms.push(newMushroom);

    // Sauvegarder la liste des champignons dans le Local Storage
    localStorage.setItem('mushrooms', JSON.stringify(mushrooms));

    // Réafficher la liste mise à jour des champignons
    displayMushrooms();

    // Masquer le formulaire après l'ajout
    document.getElementById('add-mushroom-form').style.display = 'none';
};

// Fonction pour supprimer un champignon
function deleteMushroom(id) {
    mushrooms = mushrooms.filter(mushroom => mushroom.id !== id);

    // Mettre à jour le Local Storage après suppression
    localStorage.setItem('mushrooms', JSON.stringify(mushrooms));

    // Réafficher la liste mise à jour
    displayMushrooms();

    // Masquer les détails si le champignon sélectionné a été supprimé
    document.getElementById("mushroom-details").style.display = "none";
}

// Fonction pour modifier un champignon
function editMushroom(id) {
    let mushroom = mushrooms.find(m => m.id === id);
    if (mushroom) {
        const newHumidity = prompt("Nouvelle humidité", mushroom.humidity) || mushroom.humidity;
        const newTemperature = prompt("Nouvelle température idéale", mushroom.temperature) || mushroom.temperature;
        const newOrigin = prompt("Nouveau pays d'origine", mushroom.origin) || mushroom.origin;

        // Mettre à jour les propriétés du champignon
        mushroom.humidity = newHumidity;
        mushroom.temperature = newTemperature;
        mushroom.origin = newOrigin;

        // Sauvegarder les modifications dans le Local Storage
        localStorage.setItem('mushrooms', JSON.stringify(mushrooms));

        // Réafficher la liste mise à jour des champignons
        displayMushrooms();
        displayDetails(mushroom);
    }
}

// Initialiser l'affichage en récupérant les champignons depuis le Local Storage
displayMushrooms();
